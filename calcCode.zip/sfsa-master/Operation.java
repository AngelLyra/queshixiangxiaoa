package feng;

public abstract class Operation {
	abstract double getResult(double num1,double num2);

}
