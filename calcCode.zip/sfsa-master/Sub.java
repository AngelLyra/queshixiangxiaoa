package feng;

import java.util.Scanner;

public class Sub extends Operation{

	@Override
	double getResult(double num1,double num2) {
		// TODO Auto-generated method stub
	
		return num1-num2;
	}

}
